package com.example.atividade_01

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
